    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import model.InvoiceHeader;
import model.InvoiceHeaderTableModel;

import model.InvoiceLine;
import model.InvoiceLineTableModel;
import view.AddLineDialog;
import view.CreateInvoiceDialog;
import view.JFrameForm;

/**
 *
 * @author Abdullah
 */
public class Controller implements ActionListener , ListSelectionListener{
    
    private JFrameForm frame ;
    public Controller (JFrameForm frame){
        this.frame = frame ;
    }
    private CreateInvoiceDialog invDialog;
    private AddLineDialog lineDialog;


    @Override
    public void actionPerformed(ActionEvent e) {
        
       switch (e.getActionCommand()) {
            case "Create Invoice":
                createInvoice();
                break;
            case "Delete Invoice":
                deleteInvoice();
                break;
            case "Create Item":
                createItem();
                break;
            case "Delete Item":
                deleteItem();
                break;
            case "Load Files":
                loadFiles(null, null);
                break;
            case "Save Data":
                saveData();
                break;
                
            case "createInvoiceCreateBtn":
                createInvoiceCreateBtn();
                break;
            case "createInvoiceCancelBtn":
                createInvoiceCancelBtn();
                break;
            case "createLineAddBtn":
                createLineAddBtn();
                break;
            case "createLineCancelBtn":
                createLineCancelBtn();
                break;
        }
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        
         int selectedIndex = frame.getInvoicesTable().getSelectedRow();
         if(selectedIndex != -1 ){
             InvoiceHeader invHeader = frame.getInvoices().get(selectedIndex);
             frame.getInvoiceNumLabel().setText(""+ invHeader.getNum());
             frame.getCustomerNameLabel().setText(invHeader.getName());
             frame.getInvoiceDateLabel().setText(JFrameForm.sdf.format(invHeader.getDate()));
             frame.getInvoiceTotalLabel().setText(""+ invHeader.getTotal());
             InvoiceLineTableModel lineTableModel = new InvoiceLineTableModel(invHeader.getLines());
             frame.getItemsTable().setModel(lineTableModel);
             frame.setLineTableModel(lineTableModel);
            
         }
         else{
             frame.getInvoiceNumLabel().setText("");
             frame.getCustomerNameLabel().setText("");
             frame.getInvoiceDateLabel().setText("");
             frame.getInvoiceTotalLabel().setText("");
             
             InvoiceLineTableModel LineTableModel = new InvoiceLineTableModel();
             frame.getItemsTable().setModel(LineTableModel);
             frame.setLineTableModel(LineTableModel);
            
         }
        
    }
       public void loadFiles(String headrPath, String linePath) {
        File headerFile = null;
        File lineFile = null;
        if (headrPath == null && linePath == null) {
            JFileChooser fc = new JFileChooser();
            int result = fc.showOpenDialog(frame);
            if (result == JFileChooser.APPROVE_OPTION) {
                headerFile = fc.getSelectedFile();
                result = fc.showOpenDialog(frame);
                if (result == JFileChooser.APPROVE_OPTION) {
                    lineFile = fc.getSelectedFile();
                }
            }
        } else {
            headerFile = new File(headrPath);
            lineFile = new File(linePath);
        }

        if (headerFile != null && lineFile != null) {
            try {
                /*
                1,22-11-2020,Ali
                2,13-10-2021,Saleh
                 */
                // collection streams
                List<String> headerLines = Files.lines(Paths.get(headerFile.getAbsolutePath())).collect(Collectors.toList());
                /*
                1,Mobile,3200,1
                1,Cover,20,2
                1,Headphone,130,1	
                2,Laptop,9000,1
                2,Mouse,135,1
                 */
                List<String> lineLines = Files.lines(Paths.get(lineFile.getAbsolutePath())).collect(Collectors.toList());
                //ArrayList<Invoice> invoices = new ArrayList<>();
                frame.getInvoices().clear();
                for (String headerLine : headerLines) {
                    String[] parts = headerLine.split(",");  // "1,22-11-2020,Ali"  ==>  ["1", "22-11-2020", "Ali"]
                    String numString = parts[0];
                    String dateString = parts[1];
                    String name = parts[2];
                    int num = Integer.parseInt(numString);
                    Date date = frame.sdf.parse(dateString);
                    InvoiceHeader inv = new InvoiceHeader(num, date, name);
                    //invoices.add(inv);
                    frame.getInvoices().add(inv);
                }
                System.out.println("Check point");
                for (String lineLine : lineLines) {
                    // lineLine = "1,Mobile,3200,1"
                    String[] parts = lineLine.split(",");
                    /*
                    parts = ["1", "Mobile", "3200", "1"]
                     */
                    int num = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    double price = Double.parseDouble(parts[2]);
                    int count = Integer.parseInt(parts[3]);
                    InvoiceHeader inv = frame.getInvoiceByNum(num);
                    InvoiceLine line = new InvoiceLine(name, price, count, inv);
                    inv.getLines().add(line);
                }
                System.out.println("Check point");
                frame.setHeaderTableModel( new InvoiceHeaderTableModel(frame.getInvoices()));
                   frame.getInvoicesTable().setModel(frame.getHeaderTableModel());
                           
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private void createInvoice() {
        invDialog = new CreateInvoiceDialog(frame);
        invDialog.setVisible(true);
    }

    private void deleteInvoice() {
        int selectedInvoice = frame.getInvoicesTable().getSelectedRow();
        if (selectedInvoice != -1) {
            frame.getInvoices().remove(selectedInvoice);
            frame.getHeaderTableModel().fireTableDataChanged(); 
        }
    }

    private void createItem() {
        
        if (frame.getInvoicesTable().getSelectedRow() != -1) {
            lineDialog = new AddLineDialog(frame);
            lineDialog.setVisible(true);
        }
    }

    private void deleteItem() {
        
        
        int selectedInvoice = frame.getInvoicesTable().getSelectedRow();
        int selectedItem = frame.getItemsTable().getSelectedRow();
        if (selectedInvoice != -1 && selectedItem != -1) {
            frame.getInvoices().get(selectedInvoice).getLines().remove(selectedItem);
              
            frame.getHeaderTableModel().fireTableDataChanged();
            frame.getInvoicesTable().setRowSelectionInterval(selectedInvoice, selectedItem);
        }
    }
    

    private void saveData() {
        
         JFileChooser fc = new JFileChooser();
        int result = fc.showSaveDialog(frame);
        File headeFile = null;
        File lineFile = null;
        if (result == JFileChooser.APPROVE_OPTION) {
            headeFile = fc.getSelectedFile();
            result = fc.showSaveDialog(frame);
            if (result == JFileChooser.APPROVE_OPTION) {
                lineFile = fc.getSelectedFile();
                if (headeFile != null && lineFile != null) {
                    String headerData = "";
                    String lineData = "";
                    for (InvoiceHeader header : frame.getInvoices()) {
                        headerData += header.getAsCSV();
                        headerData += "\n";
                        for (InvoiceLine line : header.getLines()) {
                            lineData += line.getAsCSV();
                            lineData += "\n";
                        }
                    }
                    headerData = headerData.substring(0, headerData.length()-1);
                    lineData = lineData.substring(0, lineData.length()-1);
                    try {
                        FileWriter hfw = new FileWriter(headeFile);
                        FileWriter lfw = new FileWriter(lineFile);
                        
                        hfw.write(headerData);
                        lfw.write(lineData);
                        
                        hfw.flush();
                        lfw.flush();
                        
                        hfw.close();
                        lfw.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
        
    

    private void createInvoiceCreateBtn() {
        String dateStr = invDialog.getInvDateField().getText();
        String name = invDialog.getCustNameField().getText();
        createInvoiceCancelBtn();
        try {
            Date date = JFrameForm.sdf.parse(dateStr);
            int num = frame.getNextInvNum();
            InvoiceHeader header = new InvoiceHeader(num, date, name);
            frame.getInvoices().add(header);
            frame.getHeaderTableModel().fireTableDataChanged();
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(frame, "Error in Date format", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
    }

    private void createInvoiceCancelBtn() {
        invDialog.setVisible(false);
        invDialog.dispose();
        invDialog = null;
    }
    
    private void createLineAddBtn() {
         int selectedInvoiceIndex = frame.getInvoicesTable().getSelectedRow();
        InvoiceHeader invoice = frame.getInvoices().get(selectedInvoiceIndex);
        String name = lineDialog.getItemNameField().getText();
        String countStr = lineDialog.getItemCountField().getText();
        String priceStr = lineDialog.getItemPriceField().getText();
        createLineCancelBtn();
        int count = Integer.parseInt(countStr);
        double price = Double.parseDouble(priceStr);
        InvoiceLine line = new InvoiceLine(name, price, count, invoice);
        invoice.getLines().add(line);
        frame.getLineTableModel().fireTableDataChanged();
        frame.getHeaderTableModel().fireTableDataChanged();
        frame.getInvoicesTable().setRowSelectionInterval(selectedInvoiceIndex, selectedInvoiceIndex);
    }
     
    
    
    private void createLineCancelBtn() {
        
        lineDialog.setVisible(false);
        lineDialog.dispose();
        lineDialog = null;
      
    }

    
    
}
