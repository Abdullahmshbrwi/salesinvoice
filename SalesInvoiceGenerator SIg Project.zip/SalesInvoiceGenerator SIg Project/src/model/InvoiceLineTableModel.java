/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Abdullah
 */
public class InvoiceLineTableModel extends AbstractTableModel{
    
    private String[] itemLine = {"Item Name" , "Item Price" , "Count", "Item Total"};
    private ArrayList<InvoiceLine> invLine ;

    public InvoiceLineTableModel(ArrayList<InvoiceLine> invLine) {
        this.invLine = invLine;
    }
    public InvoiceLineTableModel(){
        this(new ArrayList<InvoiceLine>());
    }
    

    @Override
    public int getRowCount() {
        return invLine.size();
    }

    @Override
    public int getColumnCount() {
        return itemLine.length;
    }
    

    @Override
     public Object getValueAt(int rowIndex, int columnIndex) {
        InvoiceLine line = invLine.get(rowIndex);
        
        switch (columnIndex) {
            case 0: return line.getName();
            case 1: return line.getPrice();
            case 2: return line.getCount();
            case 3: return line.getTotal();
        }
        
        return "";
    }

    @Override
    public String getColumnName(int column) {
        return itemLine[column];
    }
}
    
